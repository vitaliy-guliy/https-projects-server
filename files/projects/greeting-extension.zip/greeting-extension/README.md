# greeting-extension
Simple extension to greet the user

Use
  - `npm install` to update dependencies
  - `vsce package` to build .vsix file
